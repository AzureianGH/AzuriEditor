import pdb
def debugX(inp, persist):
    pdb.run(inp)
    if persist:
        inpus=input("Press enter to continue...")