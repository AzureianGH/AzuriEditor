def runX(inp, persist):
    exec(inp)
    if persist:
        inpust=input("Press enter to continue...")
